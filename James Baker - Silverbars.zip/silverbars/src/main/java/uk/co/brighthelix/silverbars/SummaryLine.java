package uk.co.brighthelix.silverbars;

import java.math.BigDecimal;

class SummaryLine {
    private final BigDecimal quantityInKg;
    private final BigDecimal priceInPounds;

    public SummaryLine(BigDecimal quantityInKg, BigDecimal priceInPounds) {
        this.quantityInKg = quantityInKg;
        this.priceInPounds = priceInPounds;
    }

    public BigDecimal getPriceInPounds() {
        return priceInPounds;
    }

    public String toString() {
        return String.format("%s kg for £%s", quantityInKg, priceInPounds);
    }
}
