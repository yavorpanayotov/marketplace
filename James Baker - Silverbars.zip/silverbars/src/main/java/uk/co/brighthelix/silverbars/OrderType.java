package uk.co.brighthelix.silverbars;

import java.util.Comparator;

public enum OrderType {
    // TODO not necessarily the best place for the comparators and maybe only the direction is needed
    // but this was the simplest approach to get started and will leave like this for now.  Could refactor
    // to named comparator implementations if the rules became more complicated.  This also prevents from
    // making it user selectable but again, keeping it simple now.
    BUY(Comparator.comparing(SummaryLine::getPriceInPounds).reversed()),
    SELL(Comparator.comparing(SummaryLine::getPriceInPounds));

    private final Comparator<SummaryLine> sorter;

    OrderType(final Comparator<SummaryLine> sorter) {
        this.sorter = sorter;
    }

    public Comparator<SummaryLine> getSorter() {
        return sorter;
    }
}
