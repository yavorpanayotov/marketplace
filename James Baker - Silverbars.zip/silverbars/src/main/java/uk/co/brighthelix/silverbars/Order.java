package uk.co.brighthelix.silverbars;

import java.math.BigDecimal;

public class Order {

    private final String userId;
    //TODO should use some Quantity and Money types for precision and localisation but keeping it simple
    private final BigDecimal quantityInKg;
    private final BigDecimal priceInPounds;
    private final OrderType orderType;


    public Order(final String userId,
                 final BigDecimal quantityInKg,
                 final BigDecimal priceInPounds,
                 final OrderType orderType) {
        this.userId = userId;
        this.quantityInKg = quantityInKg;
        this.priceInPounds = priceInPounds;
        this.orderType = orderType;
    }

    public String getUserId() {
        return userId;
    }

    public BigDecimal getQuantityInKg() {
        return quantityInKg;
    }

    public BigDecimal getPriceInPounds() {
        return priceInPounds;
    }

    public OrderType getOrderType() {
        return orderType;
    }

}
