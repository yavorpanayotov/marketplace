package uk.co.brighthelix.silverbars;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static java.util.stream.Collectors.*;

public class LiveOrderBoard {
    private final List<Order> orders = new ArrayList<>();

    public void add(final Order... order) {
        this.orders.addAll(Arrays.asList(order));
    }

    public List<Order> getOrders() {
        return Collections.unmodifiableList(this.orders);
    }

    public void remove(final Order order) {
        orders.remove(order);
    }

    // Could maybe return SummaryLine object and let client decide how to format but keeping it simple for now
    // Also didn't provide a generic board method for all types as it wasn't clear from instructions if the BUY
    // and SELL should be kept separate or if they should be aggregated.  Assumed they would be kept separate.
    public List<String> getSummary(final OrderType type) {
        return orders.stream()
                .filter(order -> order.getOrderType() == type)
                .collect(groupingBy(Order::getPriceInPounds,
                        reducing(BigDecimal.ZERO, Order::getQuantityInKg, BigDecimal::add)))
                .entrySet().stream()
                .map(entry -> new SummaryLine(entry.getValue(), entry.getKey()))
                .sorted(type.getSorter())
                .map(SummaryLine::toString)
                .collect(toList());
    }
}
