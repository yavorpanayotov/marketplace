package uk.co.brighthelix.silverbars

import spock.lang.Specification

class SummaryLineTest extends Specification {

    def "should be able to get the price"() {
        given:
        BigDecimal price = new BigDecimal('99.99')
        SummaryLine summary = new SummaryLine(new BigDecimal('2.5'), price)

        when:
        BigDecimal result = summary.getPriceInPounds()

        then:
        result == price
    }

    def "should create summary text with quantity and price"() {
        given:
        SummaryLine summary = new SummaryLine(new BigDecimal('2.5'), new BigDecimal('99.99'))

        when:
        String text = summary.toString()

        then:
        text == '2.5 kg for £99.99'
    }
}
