package uk.co.brighthelix.silverbars

import spock.lang.Specification
import spock.lang.Unroll

class OrderTypeTest extends Specification {
    private static final SummaryLine MIDDLING = new SummaryLine(new BigDecimal('55.55'), new BigDecimal('5.55'))
    private static final SummaryLine CHEAP = new SummaryLine(new BigDecimal('1.1'), new BigDecimal('1.10'))
    private static final SummaryLine EXPENSIVE = new SummaryLine(new BigDecimal('100'), new BigDecimal('100.00'))

    @Unroll
    '#orderType should sort summary lines into the expected order'() {
        given:
        List<SummaryLine> summaryLines = [MIDDLING, CHEAP, EXPENSIVE]

        when:
        summaryLines.sort(orderType.sorter)

        then:
        summaryLines == expectedOrder

        where:
        orderType      || expectedOrder
        OrderType.BUY  || [EXPENSIVE, MIDDLING, CHEAP]
        OrderType.SELL || [CHEAP, MIDDLING, EXPENSIVE]
    }

}
