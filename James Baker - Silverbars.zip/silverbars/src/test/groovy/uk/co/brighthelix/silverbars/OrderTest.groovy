package uk.co.brighthelix.silverbars

import spock.lang.Specification

class OrderTest extends Specification {

    def 'should set and get order details'() {
        when:
        Order order = new Order(userId, quantityInKg, priceInPounds, orderType)

        then:
        order.getUserId() == userId
        order.getQuantityInKg() == quantityInKg
        order.getPriceInPounds() == priceInPounds
        order.getOrderType() == orderType

        where:
        userId  | quantityInKg        | priceInPounds          | orderType
        "user1" | new BigDecimal(2.5) | new BigDecimal(303.99) | OrderType.BUY
        "1234"  | new BigDecimal(2)   | new BigDecimal(305)    | OrderType.SELL
    }

}
