package uk.co.brighthelix.silverbars

import spock.lang.Specification

class LiveOrderBoardTest extends Specification {

    private LiveOrderBoard orderBoard

    def setup() {
        orderBoard = new LiveOrderBoard()
    }

    def 'should be able to add and retrieve orders'() {
        given:
        Order order = buyOrder()

        when:
        orderBoard.add(order)

        then:
        orderBoard.getOrders() == [order]
    }

    def 'should be able to add and retrieve multiple orders'() {
        given:
        Order buy = buyOrder()
        Order sell = sellOrder()

        when:
        orderBoard.add(buy, sell)

        then:
        orderBoard.getOrders() == [buy, sell]
    }

    def 'should not be able to alter orders directly'() {
        when:
        orderBoard.getOrders().add(buyOrder())

        then:
        thrown UnsupportedOperationException
    }

    def 'should be able to remove orders you have previously added'() {
        given:
        Order orderToRemove = buyOrder()
        Order orderToKeep = sellOrder()
        orderBoard.add(orderToRemove, orderToKeep)

        when:
        orderBoard.remove(orderToRemove)

        then:
        orderBoard.getOrders() == [orderToKeep]
    }

    def 'should exclude SELL when getting summary for BUY'() {
        given:
        Order buy = buyOrder()
        Order sell = sellOrder()
        orderBoard.add(buy, sell)

        when:
        List<String> summary = orderBoard.getSummary(OrderType.BUY)

        then:
        summary == ["${buy.quantityInKg} kg for £${buy.priceInPounds}".toString()]
    }

    def 'should exclude BUY when getting summary for SELL'() {
        given:
        Order buy = buyOrder()
        Order sell = sellOrder()
        orderBoard.add(buy, sell)

        when:
        List<String> summary = orderBoard.getSummary(OrderType.SELL)

        then:
        summary == ["${sell.quantityInKg} kg for £${sell.priceInPounds}".toString()]
    }

    def 'should provide summary for BUY with highest price first'() {
        given:
        Order middling = new Order('user1', new BigDecimal('55.55'), new BigDecimal('5.55'), OrderType.BUY)
        Order cheap = new Order('user1', new BigDecimal('1.1'), new BigDecimal('1.10'), OrderType.BUY)
        Order expensive = new Order('user1', new BigDecimal('100'), new BigDecimal('100.00'), OrderType.BUY)
        orderBoard.add(middling, cheap, expensive)

        when:
        List<String> summary = orderBoard.getSummary(OrderType.BUY)

        then:
        summary == [
                '100 kg for £100.00',
                '55.55 kg for £5.55',
                '1.1 kg for £1.10'
        ]
    }

    def 'should provide summary for SELL with lowest price first'() {
        given:
        Order middling = new Order('user1', new BigDecimal('55.55'), new BigDecimal('5.55'), OrderType.SELL)
        Order cheap = new Order('user1', new BigDecimal('1.1'), new BigDecimal('1.10'), OrderType.SELL)
        Order expensive = new Order('user1', new BigDecimal('100'), new BigDecimal('100.00'), OrderType.SELL)
        orderBoard.add(middling, cheap, expensive)

        when:
        List<String> summary = orderBoard.getSummary(OrderType.SELL)

        then:
        summary == [
                '1.1 kg for £1.10',
                '55.55 kg for £5.55',
                '100 kg for £100.00'
        ]
    }

    def 'should aggregate when price is the same'() {
        given:
        Order fiveKg = new Order('user1', new BigDecimal('5'), new BigDecimal('1.10'), OrderType.SELL)
        Order twentyKg = new Order('user1', new BigDecimal('20'), new BigDecimal('1.10'), OrderType.SELL)

        orderBoard.add(fiveKg, twentyKg)

        when:
        List<String> summary = orderBoard.getSummary(OrderType.SELL)

        then:
        summary == ['25 kg for £1.10']
    }

    private static Order buyOrder() {
        new Order('user1', new BigDecimal('2'), new BigDecimal('3'), OrderType.BUY)
    }

    private static Order sellOrder() {
        new Order('user2', new BigDecimal('3'), new BigDecimal('4'), OrderType.SELL)
    }
}
