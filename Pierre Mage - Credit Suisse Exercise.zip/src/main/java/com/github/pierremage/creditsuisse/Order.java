package com.github.pierremage.creditsuisse;

import java.util.Objects;

public class Order {

    //I assume the app will have less than 2,147,483,647 users
    private final int userId;
    //Chose int over BigDecimal for ease of use + - * /
    private final int quantityInGram;
    //Can price include pence? If yes, I would change this field to {@code pricePerKgInPence}.
    private final int pricePerKgInGbp;
    private final Type type;

    public Order(int userId, int quantityInGram, int pricePerKgInGBP, Type type) {
        this.userId = userId;
        this.quantityInGram = quantityInGram;
        this.pricePerKgInGbp = pricePerKgInGBP;
        this.type = type;
    }

    public Order opposite() {
        return new Order(userId, quantityInGram, pricePerKgInGbp, type.opposite());
    }

    public int getQuantityInGram() {
        return quantityInGram;
    }

    public int getPricePerKgInGbp() {
        return pricePerKgInGbp;
    }

    public Type getType() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return userId == order.userId &&
                quantityInGram == order.quantityInGram &&
                pricePerKgInGbp == order.pricePerKgInGbp &&
                type == order.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, quantityInGram, pricePerKgInGbp, type);
    }

    public enum Type {
        BUY, SELL;

        public Type opposite() {
            if (this == BUY) {
                return SELL;
            }
            return BUY;
        }
    }
}
