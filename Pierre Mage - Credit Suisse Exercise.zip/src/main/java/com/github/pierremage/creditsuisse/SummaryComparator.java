package com.github.pierremage.creditsuisse;

import java.util.Comparator;

import static com.github.pierremage.creditsuisse.Order.Type.BUY;

public class SummaryComparator implements Comparator<OrderBoardEntry> {

    @Override
    public int compare(OrderBoardEntry o1, OrderBoardEntry o2) {
        int typeComparison = o1.getType().compareTo(o2.getType());
        if (typeComparison != 0) {
            return typeComparison;
        }
        if (o1.getType() == BUY) {
            return Integer.compare(o2.getPricePerKgInGbp(), o1.getPricePerKgInGbp());
        }
        return Integer.compare(o1.getPricePerKgInGbp(), o2.getPricePerKgInGbp());
    }
}
