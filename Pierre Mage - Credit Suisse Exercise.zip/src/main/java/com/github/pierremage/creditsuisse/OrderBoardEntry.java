package com.github.pierremage.creditsuisse;

import java.util.Objects;

public class OrderBoardEntry {

    private final int quantityInGram;
    private final int pricePerKgInGbp;
    private final Order.Type type;

    public OrderBoardEntry(int quantityInGram, int pricePerKgInGbp, Order.Type type) {
        this.quantityInGram = quantityInGram;
        this.pricePerKgInGbp = pricePerKgInGbp;
        this.type = type;
    }

    public OrderBoardEntry(Order order) {
        this(order.getQuantityInGram(), order.getPricePerKgInGbp(), order.getType());
    }

    public OrderBoardEntry merge(Order order) {
        int updatedQuantity = type == order.getType()
                ? quantityInGram + order.getQuantityInGram()
                : quantityInGram - order.getQuantityInGram();
        Order.Type updatedType = updatedQuantity < 0 ? type.opposite() : type;
        return new OrderBoardEntry(Math.abs(updatedQuantity), pricePerKgInGbp, updatedType);
    }

    public int getQuantityInGram() {
        return quantityInGram;
    }

    public int getPricePerKgInGbp() {
        return pricePerKgInGbp;
    }

    public Order.Type getType() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderBoardEntry that = (OrderBoardEntry) o;
        return quantityInGram == that.quantityInGram &&
                pricePerKgInGbp == that.pricePerKgInGbp &&
                type == that.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(quantityInGram, pricePerKgInGbp, type);
    }

    @Override
    public String toString() {
        return "OrderBoardEntry{" +
                "quantityInGram=" + quantityInGram +
                ", pricePerKgInGbp=" + pricePerKgInGbp +
                ", type=" + type +
                '}';
    }
}
