package com.github.pierremage.creditsuisse;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class LiveOrderBoard {

    //I could use a TreeSet instead of a Map for summary.
    //Map is O(1) on put and get but requires sorting in `summary()` O(n log n)
    //TreeSet is O(log n) on put and get but would be sorted already for `summary()`.
    private Map<Integer, OrderBoardEntry> summary = new HashMap<>();
    private Map<Order, Integer> registeredOrders = new HashMap<>();

    public Collection<OrderBoardEntry> summary() {
        return summary.values().stream()
                .sorted(new SummaryComparator())
                .collect(Collectors.toList());
    }

    public void register(Order order) {
        summary.compute(
                order.getPricePerKgInGbp(),
                (k, v) -> (v == null) ? new OrderBoardEntry(order) : v.merge(order));
        registeredOrders.merge(order, 1, (i, j) -> i + j);
    }

    public void cancel(Order order) {
        if (registeredOrders.getOrDefault(order, -1) < 1) {
            return;
        }
        OrderBoardEntry entry = summary.compute(
                order.getPricePerKgInGbp(),
                (k, v) -> v.merge(order.opposite()));
        if (entry.getQuantityInGram() == 0) {
            summary.remove(order.getPricePerKgInGbp());
        }
        registeredOrders.compute(order, (k, v) -> v - 1);
    }
}
