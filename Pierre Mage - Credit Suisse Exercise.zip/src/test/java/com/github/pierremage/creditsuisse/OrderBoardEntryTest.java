package com.github.pierremage.creditsuisse;

import org.junit.Test;

import static com.github.pierremage.creditsuisse.Order.Type.BUY;
import static com.github.pierremage.creditsuisse.Order.Type.SELL;
import static org.assertj.core.api.Assertions.assertThat;

public class OrderBoardEntryTest {

    @Test
    public void shouldAddOrderQuantity() throws Exception {
        OrderBoardEntry entry = new OrderBoardEntry(0, 306, SELL);
        Order order = new Order(1, 1, 306, SELL);

        OrderBoardEntry updatedEntry = entry.merge(order);

        OrderBoardEntry expectedEntry = new OrderBoardEntry(1, 306, SELL);
        assertThat(updatedEntry).isEqualTo(expectedEntry);
    }

    @Test
    public void shouldSubtractOrderQuantityWhenTypeIsOpposite() throws Exception {
        OrderBoardEntry entry = new OrderBoardEntry(100, 306, SELL);
        Order order = new Order(1, 25, 306, BUY);

        OrderBoardEntry updatedEntry = entry.merge(order);

        OrderBoardEntry expectedEntry = new OrderBoardEntry(75, 306, SELL);
        assertThat(updatedEntry).isEqualTo(expectedEntry);
    }

    @Test
    public void shouldSwitchType() throws Exception {
        OrderBoardEntry entry = new OrderBoardEntry(100, 306, SELL);
        Order order = new Order(1, 125, 306, BUY);

        OrderBoardEntry updatedEntry = entry.merge(order);

        OrderBoardEntry expectedEntry = new OrderBoardEntry(25, 306, BUY);
        assertThat(updatedEntry).isEqualTo(expectedEntry);
    }
}