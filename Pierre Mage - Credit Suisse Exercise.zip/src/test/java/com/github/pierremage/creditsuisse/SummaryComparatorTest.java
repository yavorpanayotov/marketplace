package com.github.pierremage.creditsuisse;

import org.junit.Test;

import static com.github.pierremage.creditsuisse.Order.Type.BUY;
import static com.github.pierremage.creditsuisse.Order.Type.SELL;
import static org.assertj.core.api.Assertions.assertThat;

public class SummaryComparatorTest {

    private SummaryComparator comparator = new SummaryComparator();

    @Test
    public void shouldSortSELLEntriesByAscendingPrice() throws Exception {
        OrderBoardEntry o1 = new OrderBoardEntry(1, 1, SELL);
        OrderBoardEntry o2 = new OrderBoardEntry(1, 2, SELL);

        assertThat(comparator.compare(o1, o2)).isLessThan(0);
    }

    @Test
    public void shouldSortBUYEntriesByAscendingPrice() throws Exception {
        OrderBoardEntry o1 = new OrderBoardEntry(1, 1, BUY);
        OrderBoardEntry o2 = new OrderBoardEntry(1, 2, BUY);

        assertThat(comparator.compare(o1, o2)).isGreaterThan(0);
    }
}