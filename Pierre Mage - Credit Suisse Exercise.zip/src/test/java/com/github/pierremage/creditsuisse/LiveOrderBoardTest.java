package com.github.pierremage.creditsuisse;

import org.junit.Before;
import org.junit.Test;

import static com.github.pierremage.creditsuisse.Order.Type.BUY;
import static com.github.pierremage.creditsuisse.Order.Type.SELL;
import static org.assertj.core.api.Assertions.assertThat;

public class LiveOrderBoardTest {

    private LiveOrderBoard board;

    @Before
    public void setUp() throws Exception {
        board = new LiveOrderBoard();
    }

    @Test
    public void shouldSummarizeASingleOrder() throws Exception {
        Order order = new Order(1, 3500, 306, SELL);

        board.register(order);

        OrderBoardEntry expectedOrderBoardEntry = new OrderBoardEntry(3500, 306, SELL);
        assertThat(board.summary()).containsOnly(expectedOrderBoardEntry);
    }

    @Test
    public void shouldMergeOrderForTheSamePrice() throws Exception {
        Order order1 = new Order(1, 3500, 306, SELL);
        Order order2 = new Order(2, 3500, 306, SELL);

        board.register(order1);
        board.register(order2);

        OrderBoardEntry expectedOrderBoardEntry = new OrderBoardEntry(7000, 306, SELL);
        assertThat(board.summary()).containsOnly(expectedOrderBoardEntry);
    }

    @Test
    public void shouldUpdateTypeWhenMergingOrderForTheSamePrice() throws Exception {
        Order order1 = new Order(1, 3500, 306, SELL);
        Order order2 = new Order(2, 5500, 306, BUY);

        board.register(order1);
        board.register(order2);

        OrderBoardEntry expectedOrderBoardEntry = new OrderBoardEntry(2000, 306, BUY);
        assertThat(board.summary()).containsOnly(expectedOrderBoardEntry);
    }

    @Test
    public void shouldCancelARegisteredOrder() throws Exception {
        Order order = new Order(1, 3500, 306, SELL);
        Order sameOrder = new Order(1, 3500, 306, SELL);
        board.register(order);

        board.cancel(sameOrder);

        assertThat(board.summary()).isEmpty();
    }

    @Test
    public void shouldIgnoreCancellationOfUnregisteredOrder() throws Exception {
        Order order1 = new Order(1, 3500, 306, SELL);
        Order order2 = new Order(2, 5500, 306, BUY);
        board.register(order1);

        board.cancel(order2);

        OrderBoardEntry expectedOrderBoardEntry = new OrderBoardEntry(3500, 306, SELL);
        assertThat(board.summary()).containsOnly(expectedOrderBoardEntry);
    }

    @Test
    public void shouldSortSELLOrdersByAscendingPrice() throws Exception {
        Order order1 = new Order(1, 1, 310, SELL);
        Order order2 = new Order(2, 1, 306, SELL);

        board.register(order1);
        board.register(order2);

        assertThat(board.summary()).containsExactly(
                new OrderBoardEntry(1, 306, SELL),
                new OrderBoardEntry(1, 310, SELL));
    }

    @Test
    public void shouldSortBUYOrdersByDescendingPrice() throws Exception {
        Order order1 = new Order(1, 1, 306, BUY);
        Order order2 = new Order(2, 1, 310, BUY);

        board.register(order1);
        board.register(order2);

        assertThat(board.summary()).containsExactly(
                new OrderBoardEntry(1, 310, BUY),
                new OrderBoardEntry(1, 306, BUY));
    }
}