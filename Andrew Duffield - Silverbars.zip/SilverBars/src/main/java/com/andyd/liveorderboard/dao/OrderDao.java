package com.andyd.liveorderboard.dao;

import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderType;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * These are the data storage operations that are permissible on an order. Standard CRUD operations for the
 * purpose of this assignment.
 */
public interface OrderDao {


    /**
     * Save the Order to the datastore.
     *
     * @param order the order to save.
     * @return the order id if the order is saved, otherwise -1.
     */
    int save(Order order);


    /**
     * Deletes an order from the datastore.<br>
     *
     * @param order the order to delete.
     * @return true if the deletion was successful.
     */
    boolean delete(Order order);


    Order cancelOrder(Order order);

    Map<Integer, Order> getOrdersByPriceAndDirection(BigDecimal price, OrderType orderType);


    Map<Integer, Order> getOrdersByDirection(OrderType orderType);


    /**
     * Get all of the orders in the datastore
     *
     * @return tne list of orders available.
     */
    Map<Integer, Order> getOrders();


}
