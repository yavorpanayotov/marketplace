package com.andyd.liveorderboard.domain;


public enum OrderType {

    SELL,
    BUY
    ;
}
