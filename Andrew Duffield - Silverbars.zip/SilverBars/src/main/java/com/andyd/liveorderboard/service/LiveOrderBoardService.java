package com.andyd.liveorderboard.service;

import com.andyd.liveorderboard.dao.OrderDao;
import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderSummary;
import com.andyd.liveorderboard.domain.OrderType;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The live order board observer. This class will be responsible for updating order summaries for buy and sell orders on
 * the Live Order Board. Implements {@link OrderChangeObserver} to receive updates when orders are added/changed.
 */
public class LiveOrderBoardService implements OrderChangeObserver {

    private final Map<OrderType, List<OrderSummary>> sortedOrderSummaryCache = new HashMap<>();

    private final Map<OrderType, Map<Integer, Order>> cachedOrders = new HashMap<>();

    private List<OrderSummary> summarisedBuy = new ArrayList<>();

    private List<OrderSummary> summarisedSell = new ArrayList<>();

    /**
     * Initialises the Live Order Board with the current set of Orders.
     *
     * @param orderDao The DAO to fetch the order data.
     */
    public LiveOrderBoardService(final OrderDao orderDao) {


        Map<Integer, Order> buyOrders = orderDao.getOrdersByDirection(OrderType.BUY);
        cachedOrders.put(OrderType.BUY,buyOrders);
        summarisedBuy = buySorter(buyOrders);
        sortedOrderSummaryCache.put(OrderType.BUY, summarisedBuy);

        Map<Integer, Order> sellOrders = orderDao.getOrdersByDirection(OrderType.SELL);
        cachedOrders.put(OrderType.SELL, sellOrders);
        summarisedSell = sellSorter(sellOrders);
        sortedOrderSummaryCache.put(OrderType.SELL, summarisedSell);

    }

    private List<OrderSummary> sellSorter(Map<Integer, Order> sellOrders) {
        Map<BigDecimal, List<OrderSummary>> mergedSell = createOrderSummariesByPrice(getOrdersAsList(sellOrders));
        List<OrderSummary> ss = getSummarisedOrders(mergedSell);
        sellSort(ss);
        return ss;
    }

    private List<OrderSummary> buySorter(Map<Integer, Order> buyOrders) {
        Map<BigDecimal, List<OrderSummary>> mergedBuy = createOrderSummariesByPrice(getOrdersAsList(buyOrders));
        List<OrderSummary> sb = getSummarisedOrders(mergedBuy);
        buySort(sb);
        return sb;
    }

    @Override
    public synchronized void onUpdate(Order order) {

        if (order.getOrderType().equals(OrderType.BUY)) {
            Map<Integer, Order> buyOrders = cachedOrders.get(OrderType.BUY);

            if(order.getOrderState().equals(Order.OrderState.CANCELLED)){
                buyOrders.remove(order.getOrderId());
            }
            else{
                buyOrders.put(order.getOrderId(), order);
            }

            summarisedBuy = buySorter(buyOrders);
            sortedOrderSummaryCache.put(OrderType.BUY, summarisedBuy);
        } else {
            Map<Integer, Order> sellOrders = cachedOrders.get(OrderType.SELL);

            if(order.getOrderState().equals(Order.OrderState.CANCELLED)){
                sellOrders.remove(order.getOrderId());
            }
            else{
                sellOrders.put(order.getOrderId(), order);
            }

            sellOrders.put(order.getOrderId(), order);
            summarisedSell = sellSorter(sellOrders);
            sortedOrderSummaryCache.put(OrderType.SELL, summarisedSell);
        }

    }


    /**
     * Filters {@link Order}s by order type.<br>
     * Maps these {@link Order}s to {@link OrderSummary} objects.<br>
     * Groups the {@link OrderSummary}s by price
     *
     * @param orders the orders to create the {@link OrderSummary}s from
     * @return a Map with key - a unit of price, and value, a list of {@link OrderSummary} objects at the key price
     */
    private Map<BigDecimal, List<OrderSummary>> createOrderSummariesByPrice(List<Order> orders) {

        return orders.stream()
//                .filter(order -> order.getOrderType() == orderType)
                .map(order -> new OrderSummary(order.getOrderQuantity(), order.getPricePerKg(), order.getOrderType()))
                .collect(Collectors.groupingBy(OrderSummary::getPrice));
    }


    /**
     * Reduces the {@link OrderSummary} Map by combining OrderSummaries where they have equivalent prices.
     *
     * @param orderSummaryByPrice a Map with key - a unit of price, and value, a list of {@link OrderSummary} objects at the key price
     * @return the final list of {@link OrderSummary} objects to display.
     */
    private List<OrderSummary> getSummarisedOrders(Map<BigDecimal, List<OrderSummary>> orderSummaryByPrice) {

        return orderSummaryByPrice
                .values()
                .stream()
                .map(a -> a.stream().reduce(OrderSummary::addPriceForSameWeight).get())
                .collect(Collectors.toList());
    }


    private List<OrderSummary> buySort(List<OrderSummary> orderSummaries) {

        sort(orderSummaries, OrderType.BUY);
        return orderSummaries;
    }


    private List<OrderSummary> sellSort(List<OrderSummary> orderSummaries) {

        sort(orderSummaries, OrderType.SELL);
        return orderSummaries;
    }

    private void sort(List<OrderSummary> orderSummaries, OrderType type) {

        Comparator<OrderSummary> comp = Comparator.comparing(OrderSummary::getDoublePrice);
        if (type == OrderType.BUY)
            comp = comp.reversed();
        orderSummaries.sort(comp);
    }

    private List<Order> getOrdersAsList(Map<Integer, Order> orders) {
        return orders.entrySet().stream()
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());
    }


    List<OrderSummary> getSellOrderSummaryList() {
        return sortedOrderSummaryCache.get(OrderType.SELL);
    }

    List<OrderSummary> getBuyOrderSummaryList() {
        return sortedOrderSummaryCache.get(OrderType.BUY);
    }
}
