package com.andyd.liveorderboard.dao;

import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderType;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * In memory implementation of the DAO - this is only used for the purposes of the exercise, in reality a database or
 * such-like would be used. I've added a few methods to deal with specific filtering criteria, thesecould be optimised
 * using DB views, Stored Procs, or filters on NO-SQL databases.
 */
public class InMemoryOrderDao implements OrderDao {

    private final Map<Integer, Order> database = new HashMap<>();

    /**
     * @param order the order to save.
     */
    public int save(Order order) {
        try {
            database.put(order.getOrderId(), order);
            return order.getOrderId();
        }
        catch(RuntimeException re){
            throw new OrderDaoException(String.format("Could not persist for order with id %1$d", order), re);
        }
    }

    /**
     * {@inheritDoc}
     * Removes the order from the Map based on the orderID key.
     */
    public boolean delete(Order order) {
        try{
            database.remove(order.getOrderId());
            return true;
        }
        catch(RuntimeException re){
            throw new OrderDaoException(String.format("Could not find order to delete for order with id %1$d", order.getOrderId()));
        }
    }

    /**
     * Cancels and Order - this doesn't remove the order from the database, it sets the cancellation flag of the order
     * in question.
     *
     * @param order the order to cancel.
     */
    public Order cancelOrder(Order order) {

        if (database.containsKey(order.getOrderId())) {
            database.get(order.getOrderId()).setCancellationFlag();
        }
        else {
            throw new OrderDaoException(String.format("Could not find order to cancel for order with id %1$d", order.getOrderId()) );
        }
        return order;
    }


    public Map<Integer, Order> getOrdersByPriceAndDirection(BigDecimal price, OrderType orderType) {
        return database.entrySet().stream()
                .filter(order -> Objects.equals(order.getValue().getPricePerKg(), price))
                .filter(order -> Objects.equals(order.getValue().getOrderType(), orderType))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    public Map<Integer, Order> getOrdersByDirection(OrderType orderType) {
        return database.entrySet().stream()
                .filter(order -> Objects.equals(order.getValue().getOrderType(), orderType))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    public Map<Integer, Order> getOrders() {
        return database;
    }
}
