package com.andyd.liveorderboard.domain;

import java.math.BigDecimal;

/**
 * Represents an Order.
 */
public class Order {


    private final int orderId;

    private final String userId;

    private final BigDecimal orderQuantity;

    private final BigDecimal pricePerKg;

    private final OrderType orderType;

    private OrderState orderState;


    public Order(final int orderId, final String userId, final BigDecimal orderQuantity,
                 final BigDecimal pricePerKg, final OrderType orderType){

        this.orderId = orderId;
        this.userId = userId;
        this.orderQuantity = orderQuantity;
        this.pricePerKg = pricePerKg;
        this.orderType = orderType;
        this.orderState = OrderState.ACTIVE;
    }


    public int getOrderId() {
        return orderId;
    }


    public BigDecimal getOrderQuantity() {

        return orderQuantity;
    }

    public String getUserId() {
        return userId;
    }

    public BigDecimal getPricePerKg() {
        return pricePerKg;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setCancellationFlag(){
        this.orderState = OrderState.CANCELLED;
    }


    public void setOrderState(OrderState orderState){
        this.orderState = orderState;
    }

    public OrderState getOrderState(){
        return orderState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Order)) return false;

        Order order = (Order) o;

        if (orderId != order.orderId) return false;
        if (!userId.equals(order.userId)) return false;
        if (!orderQuantity.equals(order.orderQuantity)) return false;
        if (!pricePerKg.equals(order.pricePerKg)) return false;
        if (orderType != order.orderType) return false;
        return orderState == order.orderState;
    }

    @Override
    public int hashCode() {
        int result = orderId;
        result = 31 * result + userId.hashCode();
        result = 31 * result + orderQuantity.hashCode();
        result = 31 * result + pricePerKg.hashCode();
        result = 31 * result + orderType.hashCode();
        result = 31 * result + orderState.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", userId='" + userId + '\'' +
                ", orderQuantity=" + orderQuantity +
                ", pricePerKg=" + pricePerKg +
                ", orderType=" + orderType +
                ", orderState=" + orderState +
                '}';
    }

    public enum OrderState {

        ACTIVE,
        CANCELLED,
        PENDING
    }
}
