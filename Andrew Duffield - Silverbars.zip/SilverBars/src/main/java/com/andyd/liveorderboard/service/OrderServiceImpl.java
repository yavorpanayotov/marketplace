package com.andyd.liveorderboard.service;

import com.andyd.liveorderboard.dao.OrderDao;
import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderSummary;

import java.util.List;

/**
 * This service is responsible for handling Orders into the system. It encapsulates the business logic for Order
 * functionality, currently non-existent in this example. The orderService can also register observers via its
 * superclass which will be notified when an update to the order's occurs.
 */
public class OrderServiceImpl extends GenericListener<OrderChangeObserver> implements OrderService{

    //The data access object.
    private final OrderDao orderDao;

    public OrderServiceImpl(final OrderDao orderDao) {
        this.orderDao = orderDao;
    }

    public int registerOrder(final Order order) {
        int orderId = orderDao.save(order);
        notifyListeners(order);

        return orderId;
    }

    @Override
    public List<OrderSummary> getOrderSummary() {
        return null;
    }

    private void notifyListeners(Order order) {
        this.notifyListeners((listener) -> listener.onUpdate(order));
    }


    public Order cancelOrder(Order order) {
        Order cancelledOrder = orderDao.cancelOrder(order);
        this.notifyListeners((listener) -> listener.onUpdate(order));
        return cancelledOrder;

    }


}
