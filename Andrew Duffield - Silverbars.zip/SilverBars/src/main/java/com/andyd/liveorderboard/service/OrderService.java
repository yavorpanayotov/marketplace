package com.andyd.liveorderboard.service;

import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderSummary;

import java.util.List;

/**
 * This is the order service that will manage the registration, maintenance, and deletion of Orders.
 */
public interface OrderService {


    int registerOrder(Order order);

    Order cancelOrder(Order order);

    List<OrderSummary> getOrderSummary();





}

