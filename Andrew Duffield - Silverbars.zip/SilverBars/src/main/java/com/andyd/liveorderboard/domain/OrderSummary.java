package com.andyd.liveorderboard.domain;

import java.math.BigDecimal;

/**
 * this is an OrderSummary primarily used for display purposes.
 */
public class OrderSummary {

    private final BigDecimal price;

    private final BigDecimal weight;

    private final OrderType orderType;

    /**
     * Constructs a immutable OrderSummary.
     *
     * @param weight
     * @param price
     * @param orderType
     */
    public OrderSummary(final BigDecimal weight, final BigDecimal price, final OrderType orderType) {
        this.price = price;
        this.weight = weight;
        this.orderType = orderType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public Double getDoublePrice() {
        return price.doubleValue();
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public Double getDoubleWeight() {
        return weight.doubleValue();
    }

    public OrderSummary addPriceForSameWeight(OrderSummary that) {

        if (that == null) {
            throw new IllegalStateException("Cannot pass in a null OrderSummary");
        }

        return new OrderSummary(new BigDecimal(this.getDoubleWeight() + that.getDoubleWeight()),
                new BigDecimal(this.getDoublePrice()), this.orderType);

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrderSummary)) return false;

        OrderSummary that = (OrderSummary) o;

        if (!price.equals(that.price)) return false;
        if (!weight.equals(that.weight)) return false;
        return orderType == that.orderType;
    }

    @Override
    public int hashCode() {
        int result = price.hashCode();
        result = 31 * result + weight.hashCode();
        result = 31 * result + orderType.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "OrderSummary{" +
                "price=" + price +
                ", weight=" + weight +
                ", orderType=" + orderType +
                '}';
    }
}
