package com.andyd.liveorderboard.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Consumer;

/**
 * Mixin pattern to provide generic listener functionality outside of domain specific classes. Used so that domain
 * objects remain relatively uncluttered from listener methods.
 *
 * @param <Listener> A listener that can be registered,unregistered and notified of change.
 */
abstract class GenericListener<Listener> {

    private final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    private final Lock readLock = readWriteLock.readLock();
    private final Lock writeLock = readWriteLock.writeLock();

    private final List<Listener>listeners = new ArrayList<>();

    Listener registerListener(Listener listener) {
        this.writeLock.lock();
        try {
            this.listeners.add(listener);
        }
        finally {
            this.writeLock.unlock();
        }
        return listener;
    }

    void unregisterListener(Listener listener) {

        this.writeLock.lock();
        try {
            // Remove the listener from the list of the registered listeners
            this.listeners.remove(listener);
        }
        finally {
            // Unlock the writer lock
            this.writeLock.unlock();
        }
    }

    void notifyListeners(Consumer<? super Listener> consumer) {
        this.readLock.lock();
        try {
            this.listeners.forEach(consumer);
        }
        finally {
            // Unlock the reader lock
            this.readLock.unlock();
        }

    }

    List<Listener> getListenersList(){
        return listeners;
    }

}
