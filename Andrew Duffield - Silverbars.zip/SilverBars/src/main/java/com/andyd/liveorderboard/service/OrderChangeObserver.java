package com.andyd.liveorderboard.service;

import com.andyd.liveorderboard.domain.Order;

/**
 * Operations to notify when an Order has changed.
 */
public interface OrderChangeObserver {

    /**
     * Receive an update when an Order ahs changed.
     * @param order the Order that has changed.
     */
    void onUpdate(Order order);

}
