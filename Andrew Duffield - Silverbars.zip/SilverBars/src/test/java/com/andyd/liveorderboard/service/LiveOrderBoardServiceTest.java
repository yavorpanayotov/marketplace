package com.andyd.liveorderboard.service;

import com.andyd.liveorderboard.dao.InMemoryOrderDao;
import com.andyd.liveorderboard.dao.OrderDao;
import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderSummary;
import com.andyd.liveorderboard.domain.OrderType;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static junit.framework.TestCase.assertEquals;

public class LiveOrderBoardServiceTest {

    //Class under test
    private LiveOrderBoardService liveOrderBoard;

    private OrderDao orderDao;


    @Before
    public void setUp() throws Exception {
        orderDao = new InMemoryOrderDao();

        Order order4 = new Order(4, "andy4", new BigDecimal(400), new BigDecimal(450), OrderType.SELL);
        Order order1 = new Order(1, "andy1", new BigDecimal(100), new BigDecimal(150), OrderType.BUY);
        Order order2 = new Order(2, "andy2", new BigDecimal(200), new BigDecimal(250), OrderType.SELL);
        Order order3 = new Order(3, "andy3", new BigDecimal(300), new BigDecimal(150), OrderType.BUY);
        Order order5 = new Order(5, "andy5", new BigDecimal(400), new BigDecimal(450), OrderType.BUY);

        orderDao.save(order1);
        orderDao.save(order2);
        orderDao.save(order3);
        orderDao.save(order4);
        orderDao.save(order5);

        liveOrderBoard = new LiveOrderBoardService(orderDao);
    }


    @Test
    public void testInitialisedOrderBoardNoUpdates() throws Exception {
        List<OrderSummary> ssb = liveOrderBoard.getBuyOrderSummaryList();
        assertEquals(2,ssb.size());
        assertEquals("Incorrect weight", 400d, ssb.get(0).getDoubleWeight());
        assertEquals("Incorrect price", 450d, ssb.get(0).getDoublePrice());
        assertEquals("Incorrect weight", 400d, ssb.get(1).getDoubleWeight());
        assertEquals("Incorrect price", 150d, ssb.get(1).getDoublePrice());
    }

    @Test
    public void onUpdate() throws Exception {

        Order order = new Order(7, "andy3", new BigDecimal(111), new BigDecimal(150), OrderType.BUY);

        liveOrderBoard.onUpdate(order);

        List<OrderSummary> actualBuy = liveOrderBoard.getBuyOrderSummaryList();
        assertEquals("Expected 2 order summary BUY orders", 2, actualBuy.size());
        OrderSummary orderSummary = actualBuy.get(1);
        assertEquals(511.0d, orderSummary.getDoubleWeight());

        List<OrderSummary> actualSell = liveOrderBoard.getSellOrderSummaryList();

        System.out.println("actualSell = " + actualSell);

        assertEquals("Expected 2 order summary SELL orders", 2, actualSell.size());

    }


}