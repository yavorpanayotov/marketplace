package com.andyd.liveorderboard.service;


import com.andyd.liveorderboard.dao.OrderDao;
import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderServiceImplTest {

    //Class under test.
    private OrderServiceImpl orderService;

    @Mock
    private OrderDao orderDao;

    @Before
    public void setUp() {
        orderService = new OrderServiceImpl(orderDao);
    }

    @Test
    public void registerOrder() throws Exception {

        when(orderDao.save(any(Order.class))).thenReturn(123);
        Order order = createOrder(123, "Andy1", 10, 5, OrderType.BUY);
        int orderId = orderService.registerOrder(order);

        assertEquals(123, orderId);
    }


    @Test
    public void registerListenerSuccess() throws Exception {

        OrderChangeObserver oco = order -> {
        };
        OrderChangeObserver oco2 = order -> {
        };

        orderService.registerListener(oco);
        orderService.registerListener(oco2);
        List<OrderChangeObserver> listeners = orderService.getListenersList();

        assertEquals("Incorrect number of registered listeners", 2, listeners.size());
    }


    @Test
    public void unregisterListener() throws Exception {
        OrderChangeObserver oco = order -> {};

        OrderChangeObserver oco2 = order -> {};

        orderService.registerListener(oco);
        orderService.registerListener(oco2);
        List<OrderChangeObserver> listeners = orderService.getListenersList();

        orderService.unregisterListener(oco);

        assertEquals("Incorrect number of registered listeners", 1, listeners.size());
    }


    /**
     * Tests that an order can be cancelled, and the relevant Observer notified.
     */
    @Test
    public void cancelOrder() {

        OrderChangeObserver oco = Mockito.mock(OrderChangeObserver.class);
        orderService.registerListener(oco);

        Order orderToCancel = createOrder(123, "Andy1", 10, 5, OrderType.BUY);

        Order mockedOrder = createOrder(123, "Andy1", 10, 5, OrderType.BUY);
        mockedOrder.setCancellationFlag();
        when(orderDao.cancelOrder(orderToCancel)).thenReturn(mockedOrder);

        Order cancelledOrder = orderService.cancelOrder(orderToCancel);

        assertEquals(cancelledOrder.getOrderState(), Order.OrderState.CANCELLED);
        verify(oco, times(1)).onUpdate(orderToCancel);
    }


    //Utility to create an Order.
    private Order createOrder(Integer id, String userId, double quantity, double price, OrderType orderType) {
        return new Order(id, userId, new BigDecimal(quantity), new BigDecimal(price), orderType);
    }

}