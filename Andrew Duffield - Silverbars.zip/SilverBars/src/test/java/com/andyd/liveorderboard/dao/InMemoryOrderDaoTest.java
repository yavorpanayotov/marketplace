package com.andyd.liveorderboard.dao;

import com.andyd.liveorderboard.domain.Order;
import com.andyd.liveorderboard.domain.OrderType;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Map;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * Tests the functionality of the in-memory datastore.
 */
public class InMemoryOrderDaoTest {

    private OrderDao orderDao;

    @Before
    public void setUp() {
        orderDao = new InMemoryOrderDao();
        prepareDataBase();

    }

    @Test
    public void getAllOrdersSuccess() throws Exception {

        Map<Integer, Order> orders = orderDao.getOrders();
        assertEquals("database should contain three records", 3, orders.size());
    }

    @Test
    public void saveNewOrderSuccessfully() throws Exception {
        Order order = new Order(10, "Andy1", new BigDecimal(10), new BigDecimal(5), OrderType.BUY);
        orderDao.save(order);

        assertEquals("Incorrect number of records in the database", 4, orderDao.getOrders().size());
    }

    @Test (expected = OrderDaoException.class)
    public void saveNullOrderFailure() throws Exception {
        orderDao.save(null);

    }

    @Test
    public void delete() throws Exception {
        Order order = new Order(10, "Andy1", new BigDecimal(10), new BigDecimal(5), OrderType.BUY);
        orderDao.save(order);
        Map<Integer, Order> ordersBeforeDeletion = orderDao.getOrders();
        assertEquals("Incorrect number of records pre delete", 4, ordersBeforeDeletion.size());

        boolean deleted = orderDao.delete(order);
        Map<Integer, Order> ordersAfterDeletion = orderDao.getOrders();
        assertEquals("Incorrect number of records post delete", 3, ordersAfterDeletion.size());
        assertTrue(deleted);

    }

    @Test
    public void getOrdersByPriceSuccess() {
        Order order4 = new Order(4, "Andy4", new BigDecimal(10), new BigDecimal(306), OrderType.SELL);
        orderDao.save(order4);
        Map<Integer, Order> result = orderDao.getOrdersByPriceAndDirection(new BigDecimal(306d), OrderType.SELL);
        assertEquals("Incorrect number of results", 1, result.size());
    }

    @Test
    public void getOrdersByPriceFailure() throws Exception {
        Order order4 = new Order(4, "Andy4", new BigDecimal(10), new BigDecimal(306), OrderType.SELL);
        orderDao.save(order4);
        Map<Integer, Order> result = orderDao.getOrdersByPriceAndDirection(new BigDecimal(1000d), OrderType.SELL);
        assertEquals("Incorrect number of results", 0, result.size());
    }


    @Test
    public void cancelValidOrder() throws Exception {
        Order order4 = new Order(4, "Andy4", new BigDecimal(10), new BigDecimal(306), OrderType.SELL);
        orderDao.save(order4);
        assertEquals("Order state should be active", Order.OrderState.ACTIVE,order4.getOrderState());

        Order cancelOrder   = orderDao.cancelOrder(order4);
        assertEquals("Order state should be cancelled", Order.OrderState.CANCELLED,cancelOrder.getOrderState());
    }


    @Test(expected = OrderDaoException.class)
    public void cancelInvalidOrderThrowsException() throws Exception {
        Order orderNotSaved = new Order(4, "Andy4", new BigDecimal(10), new BigDecimal(306), OrderType.SELL);
        assertEquals("Order state should be active", Order.OrderState.ACTIVE, orderNotSaved.getOrderState());

        orderDao.cancelOrder(orderNotSaved);

    }

    //Utility to create an Order.
    private Order createOrder(Integer id, String userId, double quantity, double price, OrderType orderType) {
        return new Order(id, userId, new BigDecimal(quantity), new BigDecimal(price), orderType);
    }

    //Common setup for the database, simple population of some test data.
    private void prepareDataBase() {
        orderDao.save(createOrder(1, "Andy1", 10, 5, OrderType.BUY));
        orderDao.save(createOrder(2, "Andy2", 10, 5, OrderType.SELL));
        orderDao.save(createOrder(3, "Andy3", 10, 5, OrderType.BUY));

    }

}