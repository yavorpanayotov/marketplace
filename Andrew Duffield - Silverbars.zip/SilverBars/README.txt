This is my Live Order Board exercise.

to build it using Maven run:

>>mvn clean install

As per the instructions there is no UI/Web or Database.

The DAO is an in-memory representation of a database in so much as it allows you to perform basic CRUD operations on the dataset.

The service - OrderServiceImpl - is responsible for running any business logic that might be needed should, and for
validating the canonical business domain. I have also made this service implement a listener interface that will allow one to register listeners with it.
This is effectively a Pub-Sub pattern (or Observer Pattern).
I did this because in order to extend the application (perhaps someone wants another order board that displays a count of the number of orders) all
one would have to do is to create another listener implementation and register it with the service, thus following SOLID principals.

One such listener is the LiveOrderBoard itself. It is listening for update messages that the Order Service will send to it,
and it is responsible for presenting the data as per the requirements.
I did this so that when the data is backed by a "real" database, the service could update the listener with only the delta
changes rather than refreshing from the database each time. It also means that a caching strategy could be implemented relatively easily.
It also goes someway from separating the presentation elements from the business logic.


I assumed that the dataset wasn't massive otherwise I may have adopted a different strategy (perhaps a proper caching solution with more time).
 
I most definitely could have validated the order data a bit more carefully.
I could have been more careful with the synchronisation aspects
Sometimes I have chosen to use package-protected access on methods. This is so that I can unit test them. I know that this may be considered
a code smell in some instances, but I don't think in this case there were any smells.

I have generated a coverage report in the coverage directory in the root of the project.

The Oder ID should most definitely not be an int.